package com.tema1;

public class Tema1 {
    public static void main(String[] args) {


        // Tipos numericos

        byte number1 = 1;
        System.out.println("Tipo byte " + number1);
        short number2 = 2;
        System.out.println("Tipo short " + number2);

        int number3 = 3;
        System.out.println("Tipo int " + number3);
        long number4 = 4;
        System.out.println("Tipo long " + number4);

        float number5 = 2.3f;
        System.out.println("Tipo float " + number5);
        double number6 = 5.33d;
        System.out.println("Tipo double " + number6);

        // booleno
        boolean verdadero = true;
        System.out.println("Tipo boolean " + verdadero);
        boolean falso = false;
        System.out.println("Tipo boolean " + falso);

        // Texto
        char caracter = 'a';
        System.out.println("Tipo character " + caracter);
        String frase = "Esto es un string";
        System.out.println("Tipo String " + frase);

        // integer
        Integer numero = null;
        System.out.println("Tipo Integer " + numero);

    }
}